import { SafeAreaView } from "react-native-safe-area-context";
import { View, Text } from "react-native";

export default function AdminDashboard() {
  return (
    <SafeAreaView className="flex-1 bg-white" edges={["top"]}>
      <View className="px-5 pt-4">
        <Text className="text-2xl font-bold text-gray-900">Admin Dashboard</Text>
      </View>
    </SafeAreaView>
  );
}
